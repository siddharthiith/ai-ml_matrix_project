import numpy as np 
import matplotlib.pyplot as plt


def dir_vec(AB):
	return np.matmul(AB,dvec)

def normal_vec(AB):
	return np.matmul(omat, np.matmul(AB, dvec))
def dist(A,B):
	return np.sqrt((A[0]-B[0])**2+(A[1]-B[1])**2)

def line_intersection():
	n1 = np.array([2,1])
	n2 = np.array([1, -1])
	P = np.array([3,1]).T
	N = np.vstack((n1,n2))
	return np.matmul(np.linalg.inv(N),P )

def line_intersection_graph(O):
	len =100
	lam = np.linspace(0,1,len)
	x_l1 = np.zeros((2,len))
	x_l2 = np.zeros((2,len))

	A = np.array([0,3])
	A1 = np.array([1,0])

	M = np.array([3,-6])
	M1 = np.array([1,1])

	for i in range(0,len):
		temp1 = A +lam[i]*(M)
		x_l1[:,i] = temp1.T 
		temp2 = A1+lam[i]*M1
		x_l2[:,i] = temp2.T

	plt.plot(x_l1[0,:],x_l1[1,:], label ='[2 1]x=3')
	plt.plot(x_l2[0,:],x_l2[1,:],label = '[1 -1]x=1')
	plt.plot(O[0],O[1],'o')
	plt.legend(loc ='best')
	plt.grid()
	plt.show()

def find_radius(O,P):
	cir = O-P
	radius = np.matmul(cir, cir.T)
	radius = np.sqrt(radius)
	return radius


def create_circle(R,O):
	len =100
	t = np.linspace(0,2*np.pi,len)

	cir = np.zeros((2,len))
	for i  in range(0,len):
		temp1 = O +np.array([R*np.cos(t[i]),R*np.sin(t[i])])
		cir[:,i] = temp1.T

	plt.plot(cir[0,:],cir[1,:])
	plt.plot(O[0],O[1],'o',label ='centre')
	plt.plot(1,-1,'o')
	plt.grid()
	plt.axis("equal")
	plt.legend(loc = 'best')
	plt.show()

def create_tangent(O,P,R):
	len = 100
	N = P-O
	T = np.array([[0,1],[-1,0]])
	M = np.matmul(T,N)
	lam = np.linspace(-1,1,len)
	x_l1 = np.zeros((2,len))

	for i in range(0,len):
		temp1 = P + lam[i]*M
		x_l1[:,i] = temp1.T


	t = np.linspace(0,2*np.pi, len)
	cir = np.zeros((2,len))
	for i  in range(0,len):
		temp1 = O +np.array([R*np.cos(t[i]),R*np.sin(t[i])])
		cir[:,i] = temp1.T
	#x = O[0]+R*np.cos(t)
	#y = O[1]+R*np.sin(t)

	plt.plot(cir[0,:],cir[1,:])
	plt.plot(x_l1[0,:],x_l1[1,:], label ='tangent line')
	plt.plot(O[0],O[1],'o',label ='centre')
	plt.grid()
	plt.axis("equal")
	plt.legend(loc ='best')
	plt.show()


O = line_intersection()
dvec = np.array([-1,1])
omat = np.array([[0,1],[-1,0]])
P = np.array([1,-1])
OP = np.vstack((O,P)).T
n = dir_vec(OP)

line_intersection_graph(O)

R = find_radius(O,P)
create_circle(R,O)
create_tangent(O,P,R)








